# Actividad 01

25% de la Nota Final

- Primera Convocatoria 20/06/2021
- Segunda Convocatoria 05/09/2021

Para hacer las entregas hay que hacer un tag al repositorio en una fecha anterior a la fecha de entrega de la actividad, y pegar el enlace al tag del repositorio en la actividad de blackboard.

Crear un programa en el cual se vea un personaje caminando. Se provee el fichero "res/walking_animation.png", que tiene una secuencia de una animación para un personaje andando a izquierda y a derecha. Usando dicha animación el personaje deberá andar de izquierda a derecha de la pantalla, y cuando llegue al borde deberá dar la vuelta. Intentando usar el mejor método posible.

Se adjunta un video en la carpeta "res" con el resultado final esperado.