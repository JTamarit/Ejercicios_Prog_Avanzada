
** El ejercicio está en el archivo walkingirl.py

