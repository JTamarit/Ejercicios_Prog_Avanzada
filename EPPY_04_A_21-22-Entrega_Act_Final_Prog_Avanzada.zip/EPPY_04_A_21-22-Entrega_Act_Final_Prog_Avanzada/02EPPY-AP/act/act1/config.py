

class Config:

    screen_size = (640,480)
    fps = 60
    speed = 0.7
    image_speed = 20
    title ='Walking Girl'
    background_color =(0,0,0)
    filename= ['res','walking_animation.png']
    image_size = (64,128)
    init_pos= (0,350)
    total_images = 20
    images_x_line = 10


    def __init__(self):
        pass