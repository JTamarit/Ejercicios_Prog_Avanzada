some_numbers = [1,2,3,4]

def add(x,y):
    return x + y

class A:
    pass

if (__name__ == '__main__'):
    print(f"Mi lista es {some_numbers}")