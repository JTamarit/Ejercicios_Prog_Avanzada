from setuptools import setup

setup(
    name="acelga",
    version="0.0.1",
    packages=["my_pkg"]
)